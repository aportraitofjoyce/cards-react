const initialState = {}

export const passwordReducer = (state = initialState, action: any): typeof initialState => {
    switch (action.type) {
        default:
            return state
    }
}