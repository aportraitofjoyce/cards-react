const initialState = {}

export const loginReducer = (state = initialState, action: any): typeof initialState => {
    switch (action.type) {
        default:
            return state
    }
}