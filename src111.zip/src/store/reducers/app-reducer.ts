const initialState = {}

export const appReducer = (state = initialState, action: any): typeof initialState => {
    switch (action.type) {
        default:
            return state
    }
}