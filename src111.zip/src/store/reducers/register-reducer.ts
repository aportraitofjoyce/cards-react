const initialState = {}

export const registerReducer = (state = initialState, action: any): typeof initialState => {
    switch (action.type) {
        default:
            return state
    }
}