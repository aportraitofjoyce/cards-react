const initialState = {}

export const authReducer = (state = initialState, action: any): typeof initialState => {
    switch (action.type) {
        default:
            return state
    }
}