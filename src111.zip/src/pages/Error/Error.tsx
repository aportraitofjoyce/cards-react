import React, {FC} from 'react'

export const Error: FC = () => {
    return (
        <div>
            <h1>Error 404</h1>
        </div>
    )
}