import React, {FC} from 'react'

export const Profile: FC = () => {
    return (
        <div>
            <h1>Profile</h1>
        </div>
    )
}