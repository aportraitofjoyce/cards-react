import React, {FC} from 'react'

export const PasswordRecovery: FC = () => {
    return (
        <div>
            <h1>Password Recovery</h1>
        </div>
    )
}