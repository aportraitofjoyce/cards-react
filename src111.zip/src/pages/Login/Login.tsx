import React, {FC} from 'react'

export const Login: FC = () => {
    return (
        <div>
            <h1>Login</h1>
        </div>
    )
}