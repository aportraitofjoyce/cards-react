import React, {FC} from 'react'

export const NewPassword: FC = () => {
    return (
        <div>
            <h1>New Password</h1>
        </div>
    )
}